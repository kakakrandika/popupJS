alert('Halo Selamat Datang');
var lagi = true;
while(lagi === true) {
	var nama = prompt('Masukkan Nama');
	alert('Hallo ' + nama);

	lagi = confirm('Apakah anda ingin mencoba lagi ?');

}

alert('Terima kasih ');
